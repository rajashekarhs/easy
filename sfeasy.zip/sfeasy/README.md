# Easy for Salesforce Integration
Integration of Easy Archive in Salesforce